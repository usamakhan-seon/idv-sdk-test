# idlive-face-capture-web

## Installation

Install node js latest version for [your system](https://nodejs.org/en/download/)

Install package in your app (replace `./idlive-face-capture-web.tgz` with path to provided archive file)

```sh
npm i idlive-face-capture-web file:./idlive-face-capture-web.tgz
```

Import the component into your app

```js
import 'idlive-face-capture-web';
```

Add the component's html tag to the place on the page where you want to display the video from the camera

```html
<idlive-face-capture></idlive-face-capture>
```

**NOTE:** The component occupies 100% of the parent's element. Make sure it has a non-zero height and width

The component has the following optional attributes:

1. `mask_hidden` - do not show the face mask
2. `auto_capture_disabled` - disable auto capture after face detection
3. `auto_close_disabled` - do not close camera after taking a photo
4. `audio_enabled` - request media stream with audio
5. `payload_size` - size of produced payload, available values: "normal" (default) and "small"
6. `device_id` - device ID of the specific camera to be opened
7. `capture_mode` - capture mode, available values: "encryptedPayload" (default) and "singleImage"

```html
<idlive-face-capture mask_hidden></idlive-face-capture>
```

### Actions

You can interact with the component using the following methods:

1. `openCamera` - open camera and show video
2. `takePhoto` - take photo
3. `closeCamera` - close camera
4. `setEncryptionKey` - set encryption key
5. `setLicense` - set license
6. `getLicenseInfo` - get license info
7. `setExternalMeta` - set external meta
8. `setCustomQualityFunction` - set custom quality function

```js
const idliveFaceCapture = document.querySelector('idlive-face-capture');

idliveFaceCapture.openCamera();
```

### Events

The component emits the following events:
1. `beforeInitialize` - the component begins initialization
2. `initialize` - the component is initialized and ready to open camera
3. `beforeOpen` - the camera starts to open
4. `open` - the camera is open and element is ready to show video
5. `detection` - detection result
6. `beforeCapture` - the capture process started
7. `capture` - the capture process completed
8. `close` - the camera was closed
9. `error` - a critical error occurred
10. `licenseInfo` - the license info

```js
idliveFaceCapture.addEventListener('initialize', (event) => {
    // the component is ready, now you can open camera
});
```

### Example of the implementation of communication with the server

```js
idliveFaceCapture.addEventListener('capture', (event) => {
    const { photo, encryptedFile } = event.detail[0];
    const serverUrl = 'https://IAD_SERVER_URL:PORT';

    fetch(`${serverUrl}/check_capture_liveness`, {
        method: 'post',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: encryptedFile,
    })
        .then(response => response.json())
        .then(result => {
            // process result from the server
        })
        .catch(e => {
            // error
        });
})
```
