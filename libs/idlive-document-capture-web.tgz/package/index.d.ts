import {
    EventResult as EventResultCommon,
    HTMLIdLiveFaceCaptureElementEvent,
    HTMLIdLiveCaptureElement,
    Action,
    Props,
    CaptureResult,
    OpenResult,
    ErrorResult,
    LicenseInfoResult,
    OpenEvent,
    CaptureEvent,
    ErrorEvent,
    LicenseInfoEvent,
    CustomQualityFunction,
} from './common';

export interface DetectionResult {
    errors: DetectionError[]
}

export enum DetectionError {
    DOCUMENT_NOT_FOUND = 'DOCUMENT_NOT_FOUND',
    DOCUMENT_SIZE_LOWER_THAN_10_PERCENT = 'DOCUMENT_SIZE_LOWER_THAN_10_PERCENT',
    DOCUMENT_BORDERS_OUTSIDE_OF_FRAME = 'DOCUMENT_BORDERS_OUTSIDE_OF_FRAME',
    MULTIPLE_DOCUMENTS_IN_FRAME = 'MULTIPLE_DOCUMENTS_IN_FRAME',
    DOCUMENT_TOO_CLOSE_TO_BORDER = 'DOCUMENT_TOO_CLOSE_TO_BORDER',
    LICENSE_NOT_INSTALLED = 'LICENSE_NOT_INSTALLED',
}

export interface EventResult extends EventResultCommon {
    detection: DetectionResult;
}

export type DetectionEvent = HTMLIdLiveFaceCaptureElementEvent<DetectionResult>;

declare global {
    type HTMLIdLiveDocumentCaptureElement = HTMLIdLiveCaptureElement<EventResult>

    interface HTMLElementTagNameMap {
        'idlive-document-capture': HTMLIdLiveDocumentCaptureElement;
    }
}

export {
    Action,
    Props,
    CaptureResult,
    OpenResult,
    ErrorResult,
    LicenseInfoResult,
    OpenEvent,
    CaptureEvent,
    ErrorEvent,
    LicenseInfoEvent,
    CustomQualityFunction,
};
