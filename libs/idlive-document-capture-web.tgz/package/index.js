import './files/document.js';
import './files/chunk-document-detector.js';
import './files/chunk-common.js';
import './files/chunk-assets.js';
import './files/chunk-vendors.js';
