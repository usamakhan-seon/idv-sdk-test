import {
    EventResult as EventResultCommon,
    HTMLIdLiveCaptureElement,
    Action,
    Props,
    CaptureResult,
    OpenResult,
    ErrorResult,
    OpenEvent,
    CaptureEvent,
    ErrorEvent,
    CustomQualityFunction,
} from './common';

declare global {
    type HTMLIdLiveDocumentCaptureElement = HTMLIdLiveCaptureElement<EventResultCommon>

    interface HTMLElementTagNameMap {
        'idlive-document-capture': HTMLIdLiveDocumentCaptureElement;
    }
}

export {
    Action,
    Props,
    CaptureResult,
    OpenResult,
    ErrorResult,
    OpenEvent,
    CaptureEvent,
    ErrorEvent,
    CustomQualityFunction,
};
