export enum Action {
    OPEN_CAMERA = 'openCamera',
    TAKE_PHOTO = 'takePhoto',
    CLOSE_CAMERA = 'closeCamera',
    SET_ENCRYPTION_KEY = 'setEncryptionKey',
    SET_LICENSE = 'setLicense',
    SET_EXTERNAL_META = 'setExternalMeta',
    SET_ADDITIONAL_DATA = 'setAdditionalData',
    GET_LICENSE_INFO = 'getLicenseInfo',
    SET_CUSTOM_QUALITY_FUNCTION = 'setCustomQualityFunction',
}

export enum Props {
    MASK_HIDDEN = 'mask_hidden',
    AUTO_CLOSE_DISABLED = 'auto_close_disabled',
    AUTO_CAPTURE_DISABLED = 'auto_capture_disabled',
    AUDIO_ENABLED = 'audio_enabled',
    PAYLOAD_SIZE = 'payload_size',
    DEVICE_ID = 'device_id',
    FACE_NOT_CENTERED_CHECK_ENABLED = 'face_not_centered_check_enabled',
    EYES_CLOSED_CHECK_ENABLED = 'eyes_closed_check_enabled',
    DARK_IMAGE_CHECK_ENABLED = 'dark_image_check_enabled',
    FACE_BLURRY_CHECK_ENABLED = 'face_blurry_check_enabled',
    MOUTH_OPEN_CHECK_ENABLED = 'mouth_open_check_enabled',
    SUNGLASSES_DETECTED_CHECK_ENABLED = 'sunglasses_detected_check_enabled',
    CAPTURE_MODE = 'capture_mode',
    RESOLUTION = 'resolution',
    SDK_PATH = 'sdk_path',
}

export interface LicenseInfoResult {
    type: string;
    expirationDate: string;
}

export interface CaptureResult {
    photo: Blob;
    encryptedFile: Blob;
}

export interface OpenResult {
    video: HTMLVideoElement;
}

export interface ErrorResult {
    message: string;
}

export interface EventResult {
    beforeInitialize: void;
    initialize: void;
    beforeOpen: void;
    open: OpenResult;
    beforeCapture: void;
    capture: CaptureResult;
    licenseInfo: LicenseInfoResult;
    close: void;
    error: ErrorResult;
}

export type CustomQualityFunction = (imageData: ImageData) => Promise<boolean>;

export type HTMLIdLiveFaceCaptureElementEvent<K> = CustomEvent<[K]>;

export type HTMLIdLiveFaceCaptureElementEventMap<K extends EventResult> = HTMLElementEventMap & {
    [P in keyof K]: HTMLIdLiveFaceCaptureElementEvent<K[P]>;
};

export type OpenEvent = HTMLIdLiveFaceCaptureElementEvent<OpenResult>;
export type CaptureEvent = HTMLIdLiveFaceCaptureElementEvent<CaptureResult>;
export type LicenseInfoEvent = HTMLIdLiveFaceCaptureElementEvent<LicenseInfoResult>;
export type ErrorEvent = HTMLIdLiveFaceCaptureElementEvent<ErrorResult>;

export interface HTMLIdLiveCaptureElement<T extends EventResult> extends HTMLElement {
    addEventListener<K extends keyof HTMLIdLiveFaceCaptureElementEventMap<T>>(
        type: K,
        listener: (this: HTMLIdLiveCaptureElement<T>, ev: HTMLIdLiveFaceCaptureElementEventMap<T>[K]) => unknown,
        options?: boolean | AddEventListenerOptions
    ): void;
    removeEventListener<K extends keyof HTMLIdLiveFaceCaptureElementEventMap<T>>(
        type: K,
        listener: (this: HTMLIdLiveCaptureElement<T>, ev: HTMLIdLiveFaceCaptureElementEventMap<T>[K]) => unknown,
        options?: boolean | EventListenerOptions
    ): void;
    [Action.OPEN_CAMERA](): void;
    [Action.TAKE_PHOTO](): void;
    [Action.CLOSE_CAMERA](): void;
    [Action.SET_ENCRYPTION_KEY](file?: Blob | null, keyId?: string): void;
    [Action.SET_LICENSE](license: string, type: string): void;
    [Action.SET_EXTERNAL_META](meta?: string | null): void;
    [Action.SET_ADDITIONAL_DATA](data?: object | null): void;
    [Action.GET_LICENSE_INFO](type: string): void;
    [Action.SET_CUSTOM_QUALITY_FUNCTION](fn: CustomQualityFunction): void;
    [Props.MASK_HIDDEN]: boolean;
    [Props.AUTO_CLOSE_DISABLED]: boolean;
    [Props.AUTO_CAPTURE_DISABLED]: boolean;
    [Props.AUDIO_ENABLED]: boolean;
    [Props.FACE_NOT_CENTERED_CHECK_ENABLED]: boolean;
    [Props.EYES_CLOSED_CHECK_ENABLED]: boolean;
    [Props.DARK_IMAGE_CHECK_ENABLED]: boolean;
    [Props.FACE_BLURRY_CHECK_ENABLED]: boolean;
    [Props.MOUTH_OPEN_CHECK_ENABLED]: boolean;
    [Props.SUNGLASSES_DETECTED_CHECK_ENABLED]: boolean;
    [Props.PAYLOAD_SIZE]?: string;
    [Props.DEVICE_ID]?: string;
    [Props.CAPTURE_MODE]?: string;
    [Props.RESOLUTION]?: string;
    [Props.SDK_PATH]?: string;
}
